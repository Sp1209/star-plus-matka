const express = require("express");
const path = require("path");
const app = express();
const PORT = process.env.PORT || 3000;
app.use(express.static(path.join(__dirname, "public")));
app.get("/api/results", async (req, res) => {
  const url = process.env.RESULT_API_URL;
  if (!url) return res.status(503).json({ error: "No authorized results source configured." });
  try {
    const headers = { "Accept": "application/json" };
    if (process.env.RESULT_API_KEY) headers["Authorization"] = `Bearer ${process.env.RESULT_API_KEY}`;
    const response = await fetch(url, { headers, signal: AbortSignal.timeout(10000) });
    if (!response.ok) throw new Error(`Upstream status ${response.status}`);
    const raw = await response.json();
    const results = normalizeResults(raw);
    if (!results.length) throw new Error("No results found in source response");
    res.set("Cache-Control", "no-store").json({ results, updatedAt: new Date().toISOString() });
  } catch (err) {
    res.status(502).json({ error: "Results source unavailable or response format not configured." });
  }
});
function normalizeResults(raw) {
  // Adapt this function only after the chosen provider's documented JSON schema is known.
  if (Array.isArray(raw?.results)) return raw.results.map(x => ({
    name: String(x.name || x.market || "Result"),
    numbers: Array.isArray(x.numbers) ? x.numbers.map(String) : (x.number != null ? [String(x.number)] : []),
    updatedAt: x.updatedAt || x.updated_at || null
  })).filter(x => x.numbers.length);
  return [];
}
app.listen(PORT, () => console.log(`STAR Plus Matka running on port ${PORT}`));
